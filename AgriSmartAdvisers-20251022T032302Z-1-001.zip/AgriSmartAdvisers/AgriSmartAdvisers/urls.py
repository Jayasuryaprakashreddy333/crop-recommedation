from django.contrib import admin
from django.views.generic import TemplateView

from agriculture import views
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path, include

from agriculture.views import predict_crop, predict_crop_action, price_forecast, delete_crop, cropinfo, \
    getCropPredictions

urlpatterns = [

    path('database/', admin.site.urls),

    path('',TemplateView.as_view(template_name = 'index.html'),name='login'),
    # ------------------ User ----------------------
    path('user/register/', views.user_register, name='user_register'),
    path('user/login/', views.user_login, name='user_login'),
    path('user/profile/update/', views.update_profile, name='update_profile'),
    path('logout/', views.logout_view, name='logout'),

    path('crop/', predict_crop, name='crop'),
    path('predictcrop/', predict_crop_action, name='predictcrop'),
    path('getCropPredictions/', getCropPredictions, name='getCropPredictions'),
    path('delete_crop/', delete_crop, name='delete_crop'),
    path('cropinfo/', cropinfo, name='cropinfo'),

    path('price/',price_forecast, name='price'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

