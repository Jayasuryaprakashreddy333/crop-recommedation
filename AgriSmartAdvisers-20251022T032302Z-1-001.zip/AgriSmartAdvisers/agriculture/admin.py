from django.contrib import admin

# Register your models here.
from .models import (
    UserModel, CropPredictionModel
)

admin.site.register(UserModel)
admin.site.register(CropPredictionModel)