import pickle
import os

PROJECT_PATH = os.path.abspath(os.path.dirname(__name__))

def get_soil_map():
    return {0: 'Alluvial Soil', 1: 'Black soil', 2: 'Chalky Soil (Alkaline Soil)', 3: 'Clay', 4: 'Clay Loam Soil', 5: 'Loamy', 6: 'Loamy Soil', 7: 'Marly', 8: 'Marly Soil', 9: 'Peaty Soil', 10: 'Saline Soil', 11: 'Sandy Loam Soil', 12: 'Silty', 13: 'Silty Soil', 14: 'alluvial soil', 15: 'clay soil.', 16: 'loamy soil'}

def get_crop_map():
    return {0: 'apple', 1: 'banana', 2: 'blackgram', 3: 'chickpea', 4: 'coconut', 5: 'coffee', 6: 'cotton', 7: 'grapes', 8: 'jute', 9: 'kidneybeans', 10: 'lentil', 11: 'maize', 12: 'mango', 13: 'mothbeans', 14: 'mungbean', 15: 'muskmelon', 16: 'orange', 17: 'papaya', 18: 'pigeonpeas', 19: 'pomegranate', 20: 'rice', 21: 'watermelon'}


def predict_crop_model(N,P,K,temperature,ph,rainfall,soil):

    cropnames = get_crop_map()

    model = pickle.load(open(PROJECT_PATH+"/models/randomforest_model_crop.pickle", 'rb'))

    testrec = [float(N), float(P), float(K), float(temperature), float(ph),float(rainfall),float(soil)]
    print(testrec)

    result = model.predict([testrec])
    print(result)

    return cropnames[result[0]]