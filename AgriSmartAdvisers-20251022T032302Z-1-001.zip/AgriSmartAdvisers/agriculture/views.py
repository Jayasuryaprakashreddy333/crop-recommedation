# views.py
from .crop_model import predict_crop_model, get_soil_map
from .models import *
from .forms import *
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages

import os
import pandas as pd
import numpy as np
from io import BytesIO
import base64
from sklearn.metrics import mean_squared_error, mean_absolute_error
from django.shortcuts import render
from django.conf import settings
from django.core.files.storage import FileSystemStorage
import pmdarima as pm

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ------------------ User ----------------------
def user_register(request):
    form = UserForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        data = form.cleaned_data
        if not UserModel.objects.filter(username=data['username']).exists():
            UserModel.objects.create(**data)
            return render(request, 'user_register.html', {'message': 'User Registered'})
        else:
            return render(request, 'user_register.html', {'message': 'Username Already Exists'})
    return render(request, 'user_register.html', {'form': form})

def user_login(request):
    message = ""
    if request.method == "POST":
        uname = request.POST['username']
        passwd = request.POST['password']
        user = UserModel.objects.filter(username=uname, password=passwd).first()
        if user:
            request.session['username'] = uname
            request.session['role'] = 'user'
            soils = get_soil_map()
            return render(request, 'crop_prediction.html',{"soils": soils})
        else:
            message = "Invalid Credentials"
    return render(request, 'user_login.html', {'message': message})

def update_profile(request):
    username = request.session.get('username')
    try:
        user = UserModel.objects.get(username=username)
    except UserModel.DoesNotExist:
        return render(request, 'update_profile.html', {'message': 'User not found.'})

    if request.method == "POST":
        try:
            user.password = request.POST.get('password')
            user.email = request.POST.get('email')
            user.mobile = request.POST.get('mobile')
            user.save()
            messages.success(request, "Profile Updated Successfully")
        except Exception as e:
            messages.error(request, f"Error updating profile: {e}")
        return render(request, 'update_profile.html', {'user': user})
    else:
        return render(request, 'update_profile.html', {'user': user})

# ------------------ Crop ----------------------
def predict_crop(request):
    soils = get_soil_map()
    return render(request, 'crop_prediction.html',{"soils": soils})

def predict_crop_action(request):
    N = request.GET['N']
    P = request.GET['P']
    K = request.GET['K']
    temperature = request.GET['temperature']
    ph = request.GET['ph']
    rainfall = request.GET['rainfall']
    soiltype = request.GET['soiltype']

    result = predict_crop_model(N, P, K, temperature, ph, rainfall, soiltype)
    CropPredictionModel(username=request.session['username'],crop=result).save()

    return render(request, "cropinfo_" + str(result) + ".html")

def getCropPredictions(request):
    print(request.session['username'],len(CropPredictionModel.objects.filter(username=request.session['username'])))
    return render(request, "crop_results.html", {"crops":CropPredictionModel.objects.filter(username=request.session['username'])})

def delete_crop(request):
    crop_id=request.GET['crop_id']
    CropPredictionModel.objects.filter(id=crop_id).delete()
    return render(request, "crop_results.html", {"crops":CropPredictionModel.objects.filter(username=request.session['username'])})

def cropinfo(request):
    name=request.GET['name']
    return render(request,"cropinfo_"+str(name)+".html")

# ------------------ Price ----------------------
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() == 'csv'

def prepare_data(df, commodity):
    commodity_data = df[df['Commodity'] == commodity].copy()
    commodity_data['Date'] = pd.to_datetime(commodity_data['Date'], dayfirst=True)
    commodity_data.sort_values('Date', inplace=True)
    commodity_data.set_index('Date', inplace=True)
    return commodity_data['Average'].dropna()

def plot_to_base64(plt):
    img = BytesIO()
    plt.savefig(img, format='png', bbox_inches='tight')
    plt.close()
    img.seek(0)
    return base64.b64encode(img.getvalue()).decode('utf8')

def evaluate_model(y_true, y_pred, model_name):
    mse = mean_squared_error(y_true, y_pred)
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mse)
    return {
        'model': model_name,
        'mse': mse,
        'mae': mae,
        'rmse': rmse
    }

def arima_forecast(series, steps):
    model = pm.auto_arima(series, seasonal=False, stepwise=True, suppress_warnings=True)
    forecast = model.predict(n_periods=steps)
    return forecast, model

def price_forecast(request):

    context = {'commodities': []}
    upload_path = settings.MEDIA_ROOT

    if request.method == 'POST' and request.FILES.get('file'):
        file = request.FILES['file']
        if allowed_file(file.name):
            fs = FileSystemStorage(location=upload_path)
            filename = fs.save(file.name, file)
            filepath = fs.path(filename)

            try:
                df = pd.read_csv(filepath)
                commodity = request.POST.get('commodity')
                steps = int(request.POST.get('steps', 30))
                series = prepare_data(df, commodity)

                if len(series) < 30:
                    context['error'] = f'Not enough data for {commodity}. At least 30 data points are required.'
                    return render(request, 'forecast/index.html', context)

                train_size = int(len(series) * 0.8)
                train, test = series[:train_size], series[train_size:]

                arima_pred, trained_model = arima_forecast(train, len(test))
                arima_metrics = evaluate_model(test.values, arima_pred, 'ARIMA')

                future_forecast = trained_model.predict(n_periods=steps)
                last_date = series.index[-1]
                future_dates = pd.date_range(start=last_date + pd.Timedelta(days=1), periods=steps)

                future_forecast = np.insert(future_forecast, 0, series.iloc[-1])
                future_dates = future_dates.insert(0, last_date)

                print(future_dates)
                print(future_forecast)

                plt.figure(figsize=(12, 6))
                plt.plot(series.index, series, label='Historical Prices', color='blue')
                plt.plot(future_dates, future_forecast, label='Forecasted Prices (ARIMA)', color='green', linestyle='--')
                plt.title(f'{commodity} Price Forecast')
                plt.xlabel('Date')
                plt.ylabel('Average Price')
                plt.legend()
                plt.grid(True)
                plot_url = plot_to_base64(plt)

                date_price_dict = dict(zip(future_dates, future_forecast))
                print(date_price_dict)
                context.update({
                    'plot_url': plot_url,
                    'commodities': sorted(df['Commodity'].unique().tolist()),
                    'selected_commodity': commodity,
                    'steps': steps,
                    'arima_metrics': arima_metrics,
                    'result_dict':date_price_dict
                })

            except Exception as e:
                context['error'] = f'Error processing file: {str(e)}'
        else:
            context['error'] = 'Invalid file type. Please upload a CSV file.'

    # For initial load, load sample data if available
    sample_path = os.path.join(upload_path, 'sample.csv')
    if os.path.exists(sample_path):
        try:
            df = pd.read_csv(sample_path)
            context['commodities'] = sorted(df['Commodity'].unique().tolist())
        except:
            pass

    return render(request, 'price_forecast.html', context)


# ------------------ Common ----------------------
def logout_view(request):
    try:
        del request.session['username']
        del request.session['role']
    except:
        pass
    return redirect('/')


